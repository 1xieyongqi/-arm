/*
	实现点击相册后的函数
 */

#include "main.h"
#include "list.h"

#define path_name "./picture/show"

int my_pictrue(LCD_DEV_P lcd_dev)
{
	//新建链表，不要头节点
	LIST_P head = init_list();

	//开始读取目录下的图片
	dir_option(head,path_name);

	show_list(head);
printf("%d\n",__LINE__ );
	//判断点击的位置进行操作
	int x=0,y=0,p=0;
	int flag;
	LIST_P pro = head;
	while(1)
	{
		get_xy(&x,&y,&p,lcd_dev);

		//点击了上一张的话
		if(650<x && x<800 && y>0&& y<65)
		{
			//展示上一张图片
			pro = pro->prev;
			show_bmp(lcd_dev,0,0,650,480,pro->data,1);

		}

		//如果点击了下一张
		else if(650<x && x<800 && y>65&& y<130)
		{
			//展示下一张图片

			pro = pro->next;

			printf("the next：%s\n",pro->data);
			show_bmp(lcd_dev,0,0,650,480,pro->data,1);
			
		}

		//点击了缩小的话
		else if(650<x && x<800 && y>130&& y<195)
		{
			//展示一张缩小图片
			show_bmp(lcd_dev,0,0,650,480,pro->data,6);
			
		}

		//点击了放大的话
		else if(650<x && x<800 && y>195&& y<275)
		{
			//展示一张放大图片
			show_bmp(lcd_dev,0,0,650,480,pro->data,7);
			
		}

		//点击了幻灯片的话
		else if(650<x && x<800 && y>275&& y<350)
		{
			//幻灯片展示目录下的所有图片
			LIST_P p = NULL;
			int i;//用于for循环
			
			//展示链表中的所以图片
			for(p=head;p->next!=head;p=p->next)
			{
				show_bmp(lcd_dev,0,0,650,480,p->data,i%5);
				i++;
			}
			
		}

		//点击了缩略图的话
		else if(650<x && x<800 && y>350&& y<415)
		{
			//按循序展示所有图片缩小的图片
			int i,j;
			LIST_P p=head;
			
			//i为y轴坐标，j为x轴坐标，每次加上一张图片的长和宽
			for(i=0;i<480&&i+200<480;i+=200)
			{
				for(j=0;j<800&&j+150<800;j+=150)
				{
					show_bmp(lcd_dev,0,0,650,480,p->data,6);
					p=p->next;
				}
			}
			
			//点击缩略图后，跳转到相应图片
			//调用本函数，如果点击返回就回到缩略图界面
			reduce_pic(head);			
		}

		//点击了返回的话的话
		else if(650<x && x<800 && y>415&& y<480)
		{
			//结束这个函数，返回上一个函数
			fc_flag = 0;//把fc_flag置为0，然后返回主函数后继续从主界面继续开始
			
			break;			
		}
	}

	free_list(head);
	return 0;
}